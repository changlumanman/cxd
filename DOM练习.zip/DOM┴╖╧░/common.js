/**
 * Created by chenxudong on 2018/7/28.
 */


function getElement(id) {
    
    return document.getElementById(id)
}