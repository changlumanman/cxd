
function getElement(id){

return document.getElementById(id);

}