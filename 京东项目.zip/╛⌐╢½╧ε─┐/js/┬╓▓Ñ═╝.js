function getElement(){

	return document.getElementById();

}


var olObj = getElement("olObj");

var list = olObj.child